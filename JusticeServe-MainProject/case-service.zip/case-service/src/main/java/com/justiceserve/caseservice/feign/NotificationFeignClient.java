package com.justiceserve.caseservice.feign;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;

/**
 * Feign client — calls notification-service to send in-app notifications.
 * Used by case-service, hearing-service, judgment-service.
 */
@FeignClient(name = "notification-service")
public interface NotificationFeignClient {
    @PostMapping("/api/notifications")
    void send(@RequestBody Map<String, Object> request);
}
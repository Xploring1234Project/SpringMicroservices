package com.justiceserve.hearingservice.feign;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * Feign client — calls case-service to update case status when hearing is scheduled.
 */
@FeignClient(name = "case-service")
public interface CaseFeignClient {
    @PatchMapping("/api/cases/{id}/status")
    void updateStatus(@PathVariable Long id, @RequestParam String status);
}
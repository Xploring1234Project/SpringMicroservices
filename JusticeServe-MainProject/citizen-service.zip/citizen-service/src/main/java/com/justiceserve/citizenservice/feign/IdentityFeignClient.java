package com.justiceserve.citizenservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Fetches user data from identity-service.
 * citizen-service does NOT have a local users table.
 */
@FeignClient(name = "identity-service")
public interface IdentityFeignClient {

    @GetMapping("/api/users/{id}")
    UserDto getUserById(@PathVariable Long id);

    record UserDto(Long userId, String name, String email, String phone, String role, String status) {}
}
